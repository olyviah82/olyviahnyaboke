<!DOCTYPE html>
<html>

<head>
    <title>
        LAB1|CREATEACCOUNT

    </title>
    <link rel="stylesheet" href="create.css">
</head>

<body>
    <form>
        <h2>REGISTER FORM</h2 <fieldset>

        <div class="container">


            <div class="picture-container">
                <div class="picture">
                    <img src="avatar.png" id="" />

                </div>
                <h6>Profile Picture</h6>
            </div>
            <div class="col1">
                <label for="fullname">Fullname</label>
                <input class="names" type="text" name="fullname" id="fullname" placeholder="your fullname" required />
            </div>
            <button class="registerbtn" type="submit">LOG OUT</button>

    </form>

</body>

</html>